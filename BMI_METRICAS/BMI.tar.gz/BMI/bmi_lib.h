#ifndef BMI_LIB_H_INCLUDED
#define BMI_LIB_H_INCLUDED
#include "bmi_lib.cpp"
#include <iostream>

void procesos();
float calculoBMI();
void clasificacion(float bmi);




#endif