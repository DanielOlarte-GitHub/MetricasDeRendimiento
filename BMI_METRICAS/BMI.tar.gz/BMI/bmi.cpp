#include <stdio.h>
#include "bmi_lib.h"

int main(){
    procesos();
    clasificacion(calculoBMI());
    return 0;
}